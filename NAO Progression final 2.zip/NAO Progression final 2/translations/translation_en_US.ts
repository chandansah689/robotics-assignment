<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Get Localized Text</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Hello Hamza</source>
            <comment>Text</comment>
            <translation type="obsolete">Hello Hamza</translation>
        </message>
        <message>
            <source>Hello, i'm you're personal physiotherapist.</source>
            <comment>Text</comment>
            <translation type="obsolete">Hello, i'm you're personal physiotherapist.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Hello, i'm you're personal physiotherapist. What do you need help with?</source>
            <comment>Text</comment>
            <translation type="unfinished">Hello, i'm you're personal physiotherapist. What do you need help with?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Benchored</source>
            <comment>Text</comment>
            <translation type="obsolete">Benchored</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>How can i help you today?</source>
            <comment>Text</comment>
            <translation type="unfinished">How can i help you today?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (10)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Are you feeling any discomfort or pains? reply with Yes or No.</source>
            <comment>Text</comment>
            <translation type="unfinished">Are you feeling any discomfort or pains? reply with Yes or No.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (11)</name>
        <message>
            <source>Shoulder pains play a big part of your body. Shoulders help us to kee[ our posture up.</source>
            <comment>Text</comment>
            <translation type="obsolete">Shoulder pains play a big part of your body. Shoulders help us to kee[ our posture up.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Shoulder pains play a big part of your body. Shoulders help us to keep our posture up.</source>
            <comment>Text</comment>
            <translation type="unfinished">Shoulder pains play a big part of your body. Shoulders help us to keep our posture up.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (12)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Sorry i didn't understand, please repeat.</source>
            <comment>Text</comment>
            <translation type="unfinished">Sorry i didn't understand, please repeat.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (13)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Move your neck side to side 15 times, then move it in circular motion, are you still feeling any more pain?</source>
            <comment>Text</comment>
            <translation type="unfinished">Move your neck side to side 15 times, then move it in circular motion, are you still feeling any more pain?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (2)</name>
        <message>
            <source>which one?</source>
            <comment>Text</comment>
            <translation type="obsolete">which one?</translation>
        </message>
        <message>
            <source>Lay back and rest and let me do my best.</source>
            <comment>Text</comment>
            <translation type="obsolete">Lay back and rest and let me do my best.</translation>
        </message>
        <message>
            <source>Lay down and rest your head and take deep breathes until your mind is relaxed.</source>
            <comment>Text</comment>
            <translation type="obsolete">Lay down and rest your head and take deep breathes until your mind is relaxed.</translation>
        </message>
        <message>
            <source>Lay down and rest your head, and take deep breathes until your mind is relaxed.</source>
            <comment>Text</comment>
            <translation type="obsolete">Lay down and rest your head, and take deep breathes until your mind is relaxed.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Lay down and rest your head, and take deep breath's until your mind is relaxed.</source>
            <comment>Text</comment>
            <translation type="unfinished">Lay down and rest your head, and take deep breath's until your mind is relaxed.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (3)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Now Physiotherapist activated.</source>
            <comment>Text</comment>
            <translation type="unfinished">Now Physiotherapist activated.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (4)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Aslam alay come</source>
            <comment>Text</comment>
            <translation type="obsolete">Aslam alay come</translation>
        </message>
        <message>
            <source>What do you need help with? Lower limb or upper limb pains?</source>
            <comment>Text</comment>
            <translation type="obsolete">What do you need help with? Lower limb or upper limb pains?</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Where do you feel pain?</source>
            <comment>Text</comment>
            <translation type="unfinished">Where do you feel pain?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (5)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Are you feeling any pain or discomfort in you're arm?</source>
            <comment>Text</comment>
            <translation type="unfinished">Are you feeling any pain or discomfort in you're arm?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (6)</name>
        <message>
            <source>First warm up your arms. You can do this by stretching you're arms across your body slowly.</source>
            <comment>Text</comment>
            <translation type="obsolete">First warm up your arms. You can do this by stretching you're arms across your body slowly.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Stretch the affected area, and walk around while taking some deep breath's</source>
            <comment>Text</comment>
            <translation type="unfinished">Stretch the affected area, and walk around while taking some deep breath's</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (7)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Okay, is there anything else i can help you with today?</source>
            <comment>Text</comment>
            <translation type="unfinished">Okay, is there anything else i can help you with today?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (8)</name>
        <message>
            <source>Okay, let me know if you need additional assitance, goodbye!</source>
            <comment>Text</comment>
            <translation type="obsolete">Okay, let me know if you need additional assitance, goodbye!</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Okay, let me know if you need additional assistance, goodbye!</source>
            <comment>Text</comment>
            <translation type="unfinished">Okay, let me know if you need additional assistance, goodbye!</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (9)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>It's always best to stretch out you're legs when you have any muscle or joint pains.</source>
            <comment>Text</comment>
            <translation type="unfinished">It's always best to stretch out you're legs when you have any muscle or joint pains.</translation>
        </message>
    </context>
</TS>
